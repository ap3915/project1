<?php

session_start();
include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';


if(isset($_SESSION['customer'])!="")
{
	header("Location: index.html");
}

if(isset($_POST['register-submit'])){

	$uname = mysql_real_escape_string($_POST['username']);
	$email = mysql_real_escape_string($_POST['email']);
	$upass = mysql_real_escape_string($_POST['password']);}
	
	if(mysql_query("INSERT INTO customer(username,email,password) VALUES('$uname','$email','$upass')"))
	{
		?>
        <script>alert('successfully registered ');
 window.location.href="index.html";</script>
        <?php
       
	}
	else
	{
		?>
        <script>alert('error while registering you...');</script>
        <?php
        header("Location: index.html");
	}

?>
