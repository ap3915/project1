<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['user']))
{
 header("Location: login.php");
}
$res=mysql_query("SELECT * FROM user WHERE user_id=".$_SESSION['user']);
$userRow=mysql_fetch_array($res);
?>

<html>
<head>
<title>Nur Cafe Online</title>
<title>Welcome - <?php echo $userRow['username']; ?></title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../css/style.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary JavaScript plugins) -->
<script type='text/javascript' src="js/jquery-1.11.1.min.js"></script>
<!-- Custom Theme files -->
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Hot Foods Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script> 
</head>
<body>
<!-- header -->
<div class="banner banner2">
	 <div class="container">
		 <div class="banner_head_top">
			 <div class="banner-head">
				 <div class="logo">
					 <h1><a href="index.html">Hot<span class="glyphicon glyphicon-cutlery" aria-hidden="true"></span><span>Foods</span></a></h1>
				 </div>
				 <div class="headr-right">
					 <div class="details">
						 <ul>
							 <li><a href="mailto:@example.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>info(at)example.com</a></li>
							 <li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>(+1)000 123 456789</li>
						 </ul>
					 </div>
				 </div>
				 <div class="clearfix"></div>
			 </div>
			 <div class="top-menu">	 
			 <div class="content white">
				 <nav class="navbar navbar-default">
					 <div class="navbar-header">
						 <button type="button" class="menu" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="icon-bar">MENU</span>							
						</button>
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>				
					 </div>
					 <!--/navbar header-->		
					 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						 <ul class="nav navbar-nav">
							 <li><a href="index.html">Home</a></li>
							 <li><a href="about.html">About</a></li>
							 <li class="dropdown active">
								<a href="#" class="scroll dropdown-toggle" data-toggle="dropdown">Recipes<b class="caret"></b></a>
								<ul class="dropdown-menu">
									<li><a href="recipes.html">Recipes 1</a></li>
									<li><a href="recipes.html">Recipes 2</a></li>
									<li><a href="recipes.html">Recipes 3</a></li>
								</ul>
							 </li>					
							 <li><a href="gallery.html">Gallery</a></li>
							 <li><a href="shortcodes.html">Shortcodes</a></li>
							 <li><a href="contact.html">Contact</a></li>
						 </ul>
						</div>
					  <!--/navbar collapse-->
				 </nav>
				  <!--/navbar-->
			 </div>
				 <div class="clearfix"></div>
				<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
			  </div>
		  </div>
	 </div>	 
</div>
<!---->
<script>
		$(document).ready(function () {
		    size_li = $("#myList li").size();
		    x=2;
		    $('#myList li:lt('+x+')').show();
		    $('#loadMore').click(function () {
		        x= (x+1 <= size_li) ? x+1 : size_li;
		        $('#myList li:lt('+x+')').show();
		    });
		    $('#showLess').click(function () {
		        x=(x-1<0) ? 1 : x-1;
		        $('#myList li').not(':lt('+x+')').hide();
		    });
		});
	</script>
<div class="recp-sec">
	 <div class="container">
	 <h2>Recipes</h2>
	 <div class="recip-grid">
			 <div class="load_more">	
				<ul id="myList">
					<li><div class="l_g">
						 <div class="col-md-4 recip-sec">
							 <img src="images/r1.jpg" alt=""/>
							 <h3><a href="#">Indian Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							 <img src="images/r2.jpg" alt=""/>
							 <h3><a href="#">Sausage Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							<img src="images/r6.jpg" alt=""/>
							 <h3><a href="#">Peach Salsa</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>						 
						 <div class="clearfix"></div>
						 </div>
					</li>
					
					<li><div class="l_g">
						 <div class="col-md-4 recip-sec">
							 <img src="images/r4.jpg" alt=""/>
							 <h3><a href="#">Fish Meal</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							 <img src="images/r5.jpg" alt=""/>
							 <h3><a href="#">Bruschetta Bread</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							<img src="images/r3.jpg" alt=""/>
							 <h3><a href="#">Italian Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="clearfix"></div>
						 </div>
					</li>
					
					<li><div class="l_g">
						 <div class="col-md-4 recip-sec">
							 <img src="images/r7.jpg" alt=""/>
							 <h3><a href="#">Veg Soup</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							 <img src="images/r8.jpg" alt=""/>
							 <h3><a href="#">Potato Palca</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							<img src="images/r9.jpg" alt=""/>
							 <h3><a href="#">Mac and Cheese</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="clearfix"></div>
						 </div>
					</li>
					
					<li><div class="l_g">
						 <div class="col-md-4 recip-sec">
							 <img src="images/r1.jpg" alt=""/>
							 <h3><a href="#">Indian Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							 <img src="images/r2.jpg" alt=""/>
							 <h3><a href="#">Mexican Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="col-md-4 recip-sec">
							<img src="images/r3.jpg" alt=""/>
							 <h3><a href="#">Italian Recipes</a></h3>
							 <p>Aenean nonummy hendrerit mauris. Phasellus porta. Fusce suscipit varius mi Cum sociis penatibus.</p>
						 </div>
						 <div class="clearfix"></div>
						 </div>
					</li>
					
				 </ul>
				 <div id="loadMore">Load more</div>
				 <div id="showLess">Show less</div>

				 </div>
			 </div>
	 </div>
</div>
<!----> 
<div class="footer">
	 <div class="container">
		 <div class="footer-sec">
			 <div class="col-md-4 ftr-grid1">
				 <h3>Latest Tweets</h3>
				 <div class="twts">
					 <h5>Nunc porta justo eu varius mattis.</h5>
					 <a href="mailto:example@gmail.com">http://www.example.com</a>
				 </div>
				 <div class="twts">
					 <h5>Nunc porta justo eu varius mattis.</h5>
					 <a href="mailto:example@gmail.com">http://www.example.com</a>
				 </div>
			 </div>
			 <div class="col-md-4 news-ltr">
				 <h3>NewsLetter</h3>
				 <p>Praesent ex lectus, luctus ut enim sed, scelerisque laoreet massa. Fusce rhoncus massa dignissim suscipit varius.
				 Donec vel congue libero. </p>
				 <form>					 
					  <input type="text" class="text" value="Enter Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Email';}">
					 <input type="submit" value="Go">
					 <div class="clearfix"></div>
				 </form>
			 </div>
			 <div class="col-md-4 social">
				 <h3>Social Media</h3>
				 <a href="#"><i class="facebook"></i></a>
				 <a href="#"><i class="twitter"></i></a>
				 <a href="#"><i class="dribble"></i></a>	
				 <a href="#"><i class="google"></i></a>	
				 <a href="#"><i class="youtube"></i></a>
			 </div>
			 <div class="clearfix"></div>
     	 </div>
	 </div>
</div>
<div class="copywrite">
	<div class="container">
		<p> © 2015 Hot Foods. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
	</div>
</div>
<!---->  
</body>
</html>