<?php
session_start();
include_once 'dbconnect.php';


if(!isset($_SESSION['admin']))
{
 header("Location: login.php");
}
$res=mysql_query("SELECT * FROM admin WHERE admin_id=".$_SESSION['admin']);
$userRow=mysql_fetch_array($res);
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Nur Cafe Online</title>
<body>Welcome - <?php echo $userRow['admin']; ?><br>
    <a href="../test/admin.php">Manage</a>
</body>
    
</head>
</html>