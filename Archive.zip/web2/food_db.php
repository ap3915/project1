<?php
//make a sql connection
mysql_connect("localhost","root","root") or die(mysql_error());
mysql_select_db("dbtest") or die(mysql_error());

//select data from table
$result = mysql_query("SELECT * from makanan") or die(mysql_error());

//store the record of the table into $row
while($row = mysql_fetch_array($result)){
echo "Food Name : ".$row['name'];
echo "&nbsp;<br><br>";
echo "Price : RM ".$row['price'];
}
?>
