<?php

$obj = new makanan_db();

// Setup Our Connection Vars

$obj->host = 'localhost';
$obj->username = 'root';
$obj->password = 'root';
$obj->db = 'dbtest';

// Connect to our DB
$obj->connect();

?>