<?php

class makanan_db{
    var $host;
    var $username;
    var $password;
    var $db;
    
    function connect(){
        $con = mysql_connect($this->host,$this->username,$this->password) or die(mysql_error());
        mysql_select_db($this->db, $con) or die(mysql_error());
    }
    
    function add_content($p){
        $food_name = mysql_real_escape_string($p['name']);
        $food_price = mysql_real_escape_string($p['price']);
        $sql = "INSERT INTO makanan VALUES (null, '$food_name','$food_price')";
        $res = mysql_query($sql) or die(mysql_error());
        echo "Successfully added !";
    }
    
    function delete_order($id){
        if(!$id){
            return false;
        }else{
            $id = mysql_real_escape_string($id);
            $sql = "DELETE FROM order_table WHERE order_id = '$id'";
            $res = mysql_query($sql) or die(mysql_error());
            echo "Order Deleted !";
        }
    }
}