<?php
session_start();
include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';


if(isset($_SESSION['customer'])!="")
{
 header("Location: userhome.php");
}
if(isset($_POST['login-submit']))
{
 $uname = mysql_real_escape_string($_POST['username']);
 $upass = mysql_real_escape_string($_POST['password']);
 $res=mysql_query("SELECT * FROM customer WHERE username='$uname'");
 $row=mysql_fetch_array($res);
 if($row['password']==$upass)
 {
  $_SESSION['customer'] = $row['user_id'];
 ?>
        <script>alert('successfully login !');
            window.location.href="userhome.php";</script>
        
 <?php
 }
 else
 {
 ?> 
        <script>alert('wrong details');
            window.location.href="index.html";</script>
        
   <?php     
 }
 
}else{
    ?>
    <script>
            window.location.href="index.html";
    </script>
<?php        
}
?>
