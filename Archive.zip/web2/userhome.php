<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['customer']))
{
 header("Location: login.php");
}
$res=mysql_query("SELECT * FROM customer WHERE user_id=".$_SESSION['customer']);
$userRow=mysql_fetch_array($res);
?>


<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Nur Cafe Online</title>
<title>Welcome - <?php echo $userRow['username']; ?></title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="login.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="/css/font-awesome.min.css">
<!-- jQuery (necessary JavaScript plugins) -->
<script type='text/javascript' src="js/jquery-1.11.1.min.js"></script>
<script type='text/javascript' src="login.js"></script>

    <!-- Custom Theme files -->
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script> 
</head>
<body>
    <!-- header -->
<div class="banner">
	 <div class="container">
		 <div class="banner_head_top">
			 <div class="banner-head">
				 <div class="logo">
					 <h1><a href="index.html">NurCafe<span class="glyphicon glyphicon-cutlery" aria-hidden="true"></span><span>Online</span></a></h1>
				 </div>
				 <div class="headr-right">
					 <div class="details">
						 Welcome, <?php echo $userRow['username']; ?>&nbsp; <a href="logout.php" class="btn btn-success navbar-btn"></span> Sign Out</a>

                             
				 </div>
				 </div>


				 <div class="clearfix"></div>
			 </div>
			 <div class="top-menu">	 
			 <div class="content white">
				 <nav class="navbar navbar-default">
					 <div class="navbar-header">
						 <button type="button" class="menu" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="icon-bar">MENU</span>							
						</button>
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>	

						</button>				
					 </div>
					 <!--/navbar header-->		
					 <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						 <ul class="nav navbar-nav">
							 <li class="active"><a href="index.html"><span class="glyphicon glyphicon-home"></span> Home</a></li>
							 <li><a href="about.html"><span class="glyphicon glyphicon-heart-empty"></span> About</a></li>
							 <li class="dropdown">
								<a href="#" class="scroll dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-tasks"></span> Food Menu<b class="caret"></b></a>
								<ul class="dropdown-menu">
									<li><a href="../web2/usermenu/recipes.php">Eastern</a></li>
									<li><a href="../web2/usermenu/recipes.php">Western</a></li>
									<li><a href="../web2/usermenu/recipes.php">Tradisional</a></li>
								</ul>
							 </li>					
							 <li><a href="contact.html" ><span class="glyphicon glyphicon-phone-alt"></span> Contact</a></li>
							 <!-- <li><a href="contact.html" ><button type="button" class="btn btn-default navbar-btn"><span class="glyphicon glyphicon-shopping-cart"></span> ORDER</button></a></li> -->
							 </ul>

						 <ul class="nav navbar-nav navbar-right">
    						 <li>
        						<ul><a href="../test/menus.php" class="btn btn-danger navbar-btn"><span class="glyphicon glyphicon-shopping-cart"></span> ORDER NOW</a></ul>
    						 </li>
							 </ul>  
					</div>
					  <!--/navbar collapse-->
				 </nav>
				  <!--/navbar-->
			 </div>
				 <div class="clearfix"></div>
				<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
			  </div>
		  </div>
		  <div class="banner-info">
			 <h2>NCOOS [PROJECT WEBDESIGN]</h2>
			 <label></label>
			 <h4>Kini lebih mudah <span>Order ONLINE terus dari smartphone anda.</span></h4>
			 <p>Seiring dengan kemudahan internet kami melangkah kehadapan dengan memperkenalkan sistem pemesanan makanan secara atas talian. Anda tidak perlu lagi beratur dan menunggu lama untuk memesan makanan di cafe kami. Hanya pesan melalui smartphone anda dan kami akan menghubungi anda setelah makanan anda siap. Memperkenalkan NCOOS (Nur Cafe Online Ordering System)</p>
			 <a class="btn-left" href="about.html">Click</a>	
			 <a class="btn-right" href="about.html">Read more</a>
		 </div>
	 </div>	 
</div>
<!---->
<div class="welcome">
	 <div class="container">
		 <h3>Welcome !</h3>
		 <p>Etiam vel lectus sem. Mauris scelerisque nibh vel felis molestie, a fermentum odio fermentum. Mauris felis quam, commodo vel nibh et, bibendum dignissim ex.
		 Aliquam at ligula rutrum, convallis metus in, ornare est. Praesent feugiat erat sed lectus congue congue. Proin et libero vel sem ultricies lobortis. Praesent 
		 condimentum erat in consequat hendrerit. Suspendisse diam diam, maximus non aliquam a, consequat eget enim. Donec eu magna pellentesque, placerat tortor non, vestibulum libero.</p>
		 <div class="welcome_pic">
			 <img src="images/wel.png" alt=""/>
		 </div>		 
	</div>
</div>
<div class="company">
	 <div class="container">
		 <h3>Services</h3>
		 <div class="service-grids">
		  <div class="col-md-4 commpany-grid">
				 <div class="grid-pic">
					 <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
				 </div>
				 <div class="grid-info">
					 <h4>Quality Control</h4>
					 <p>Quisque vulputate molestie neque eget gravida. Ut hendrerit ornare est In accumsan erat at mauris interdum suscipit. </p>
				 </div>
				 <div class="clearfix"></div>
		  </div>
		  <div class="col-md-4 commpany-grid">
				 <div class="grid-pic">
					<span class="glyphicon glyphicon-euro" aria-hidden="true"></span>
				 </div>
				 <div class="grid-info">
					 <h4>Best Prices</h4>
					 <p>Quisque vulputate molestie neque eget gravida. Ut hendrerit ornare est In accumsan erat at mauris interdum suscipit. </p>
				 </div>
				 <div class="clearfix"></div>
		  </div>
		  <div class="col-md-4 commpany-grid">
				 <div class="grid-pic">
					  <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
				 </div>
				 <div class="grid-info">
					 <h4>Customer Support</h4>
					 <p>Quisque vulputate molestie neque eget gravida. Ut hendrerit ornare est In accumsan erat at mauris interdum suscipit. </p>
				 </div>
				 <div class="clearfix"></div>
		  </div>
			<div class="clearfix"></div>
			</div>
	  </div>
</div>		 
<!---->
<div class="special">
	 <div class="container">
		 <h3>Our Specials</h3>
		 <div class="arrival-grids">			 
			 <ul id="flexiselDemo1">
				 <li>
					 <a href="recipes.html"><img src="images/s1.jpg" alt=""/>
					 <h4>Prawns Fry</h4>
					 </a>
				 </li>
				 <li>
					 <a href="recipes.html"><img src="images/s4.jpg" alt=""/>
					 <h4>Chilli Carne</h4>
					 </a>
				 </li>
				 <li>
					 <a href="recipes.html"><img src="images/s3.jpg" alt=""/>
					 <h4>Grill Fry</h4>
					 </a>
				 </li>
				 <li>
					 <a href="recipes.html"><img src="images/s2.jpg" alt=""/>
					 <h4>Prawns Soup</h4>
					 </a>
				 </li>
				 <li>
					 <a href="recipes.html"><img src="images/s4.jpg" alt=""/>
					 <h4>Chilli Carne</h4>
					 </a>
				 </li>
				 <li>
					 <a href="recipes.html"><img src="images/s3.jpg" alt=""/>
					 <h4>Grill Fry</h4>
					 </a>
				 </li>
				</ul>
				<script type="text/javascript">
				 $(window).load(function() {			
				  $("#flexiselDemo1").flexisel({
					visibleItems: 4,
					animationSpeed: 1000,
					autoPlay: false,
					autoPlaySpeed: 3000,    		
					pauseOnHover:true,
					enableResponsiveBreakpoints: true,
					responsiveBreakpoints: { 
						portrait: { 
							changePoint:480,
							visibleItems: 1
						}, 
						landscape: { 
							changePoint:640,
							visibleItems: 2
						},
						tablet: { 
							changePoint:768,
							visibleItems: 3
						}
					}
				});
				});
				</script>
				<script type="text/javascript" src="js/jquery.flexisel.js"></script>			 
		  </div>

	 </div>
</div>
<!---->
<div class="latest_news">
	 <div class="container">
	     <div class="news-sec">
			 <div class="col-md-6 news">
					 <div class="news-head">
						 <h3>Latest News</h3>						 
					 </div>
					 <div class="news_grid">
						 <img src="images/l1.jpg" class="img-responsive" alt=""/>
						 <h4><a href="about.html">Mauris hendrerit ex id leo elementum congue.</a></h4>
						 <p class="date">19th June | 10:00 - 12:00</p>
						 <p>Praesent accumsan augue dolor, vel eleifend lorem pellentesque egestas. Ut sit amet iaculis erat. maximus non aliquam a, consequat eget enim. Donec eu magna pellentesque, placerat tortor non,  Cras venenatis sodales nibh non finibus.</p>
						 <a class="read" href="about.html">Read More...</a>
					 </div>
			 </div>
			 <div class="col-md-6 testimonal">
					 <div class="testi-head">
						 <h3>Testimonials</h3>
					 </div>
					 <div class="testi-grids">
						 <div class="testi-grid">
							 <div class="people">
								 <img src="images/t1.jpg" class="img-responsive" alt=""/>
							 </div>
							 <div class="testi-info">
								 <h4>Christopher</h4>
								 <a href="about.html">CEO</a>
								 <p>Nullam viverra porttitor est at vestibulum. Quisque sodales justo eu erat malesuada rutrum. Ut orci velit, dignissim ut dui convallis, sagittis cursus sem.</p>
							 </div>
							 <div class="clearfix"></div>
						 </div>
						 <div class="testi-grid testi2">
							 <div class="people">
								 <img src="images/t2.jpg" class="img-responsive" alt=""/>
							 </div>
							 <div class="testi-info">
								 <h4>Ainsley</h4>
								 <a href="about.html">Manager</a>
								 <p>Nullam viverra porttitor est at vestibulum. Quisque sodales justo eu erat malesuada rutrum. Ut orci velit, dignissim ut dui convallis, sagittis cursus sem.</p>
							 </div>
							 <div class="clearfix"></div>
						 </div>
					 </div>
			  </div>
			  <div class="clearfix"></div>
		 </div>
	 </div>
</div>
<!----> 
<div class="footer">
	 <div class="container">
		 <div class="footer-sec">
			 <div class="col-md-4 ftr-grid1">
				 <h3>Latest Tweets</h3>
				 <div class="twts">
					 <h5>Nunc porta justo eu varius mattis.</h5>
					 <a href="mailto:example@gmail.com">http://www.example.com</a>
				 </div>
				 <div class="twts">
					 <h5>Nunc porta justo eu varius mattis.</h5>
					 <a href="mailto:example@gmail.com">http://www.example.com</a>
				 </div>
			 </div>
			 <div class="col-md-4 news-ltr">
				 <h3>NewsLetter</h3>
				 <p>Praesent ex lectus, luctus ut enim sed, scelerisque laoreet massa. Fusce rhoncus massa dignissim suscipit varius.
				 Donec vel congue libero. </p>
				 <form>					 
					  <input type="text" class="text" value="Enter Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter Email';}">
					 <input type="submit" value="Go">
					 <div class="clearfix"></div>
				 </form>
			 </div>
			 <div class="col-md-4 social">
				 <h3>Social Media</h3>
				 <a href="#"><i class="facebook"></i></a>
				 <a href="#"><i class="twitter"></i></a>
				 <a href="#"><i class="dribble"></i></a>	
				 <a href="#"><i class="google"></i></a>	
				 <a href="#"><i class="youtube"></i></a>
			 </div>
			 <div class="clearfix"></div>
     	 </div>
	 </div>
</div>
<div class="copywrite">
	<div class="container">
		<p> © 2015 Hot Foods. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
	</div>
</div>
<!---->  
</body>
</html>