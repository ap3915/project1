<?php



session_start();
session_destroy();
header("Location: index.html");

if(!isset($_SESSION['user']))
{
 header("Location: index.html");
}
else if(isset($_SESSION['customer'])!="")
{
 header("Location: index.html");
}

if(isset($_GET['logout']))
{
 session_destroy();
 unset($_SESSION['customer']);
 header("Location: index.html");
}


?>