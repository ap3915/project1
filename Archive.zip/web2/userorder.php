<?php

include 'food_db.php'

?>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=windows-1252">
    <title>Nur Cafe Online</title>
    </head>
    <body style="font-family: Arial">
    <h1><br>
        Nur Cafe Online</h1>
    <p>Food Ordering Form</p>
    <form action="foodorder.php" method="post">
        <table border = 0>
        <tr>
            <td width = 150>Menu<br>&nbsp;</td>
            <td width = 150>Price (RM)<br>&nbsp;</td>
            <td width = 15>Quantity<br>&nbsp;</td>
        </tr>
        <tr>
            </tr>
        </table></form>
    </body>
    
                                                    