<?php
    session_start();
    include_once 'dbconnect.php';

    if(isset($_SESSION['admin'])!="")
    {
     header("Location: adminhome.php");
    }
    if(isset($_POST['Submit']))
    {
        $uname = mysql_real_escape_string($_POST['admin']);
        $upass = mysql_real_escape_string($_POST['pass']);
        $res=mysql_query("SELECT * FROM admin WHERE admin='$uname'");
        $row=mysql_fetch_array($res);

        if($row['pass']==$upass)
        {
          $_SESSION['admin'] = $row['admin_id'];
          header("Location: ../test/admin.php");
        }
        else
        {
?>
        <script>alert('wrong details');
        window.location.href="index.html";</script>
<?php

        }

    }
?>

 
