<?php

session_start();
include_once 'layout_head_admin.php';

 echo "<table class = 'table table-hover table-responsive table-bordered'>";
    
    //our table heading
    echo "<tr>";
    echo "<form action=\"vieworder.php\" method=\"post\">"; 
    echo "<th><center><input type=\"submit\" name=\"view_order\" tabindex=\"2\" class=\"form-control btn btn-success\" value=\"View Order\"></center></th>";
    echo "</form>";
    echo "<form action=\"update_menu.php\" method=\"post\">"; 
    echo "<th><center><input type=\"submit\" name=\"update_menu\" tabindex=\"2\" class=\"form-control btn btn-success\" value=\"Add Menu\"></center></th>";
    echo "</form>";
    echo "</tr>";

include_once 'layout_foot.php';
?>

