<?php

class makanan_db{
	 var $host;
	 var $username;
	 var $password;
	 var $db;
	 
	 function connect(){
	 $con = mysql_connect($this->host, $this->username, $this->password) or die(mysql_error());
	 mysql_select_db($this->db, $con) or die(mysql_error());
	 }
    
    
	 function get_content($id='') {

        $return = '';
         
		if($id != ""):
			$id = mysql_real_escape_string($id);
			$sql = "SELECT * FROM cms_content WHERE id= '$id'";
			
			$return= '<p><a href="index.php"> Go Back To Home</a></p>';
		else:
			$sql = "SELECT * FROM cms_content ORDER BY id DESC LIMIT 10";
		endif;
			
		$res = mysql_query($sql) or die(mysql_error());
		
		if(mysql_num_rows($res) != 0):
		
            while($row = mysql_fetch_assoc($res)) {

              echo '<h1><a href="index.php?id=' . $row['id']. '">' .$row['title']. '</a></h1>' ;
              echo '<p>' . $row['body']. '</p>';

            }
        
		else:
		  echo '<p> This page not exist. </p>';
		endif;
		
		 echo $return;
	 }
	 
	
	 function add_content($p) {
		$title = mysql_real_escape_string($p['title']);
		$body = mysql_real_escape_string($p['body']);
         
         $sql= "INSERT INTO cms_content VALUES (null, '$title', '$body')";
         $res= mysql_query($sql) or die(mysql_error());
         echo "added Succesfully!";
			
			}
	 
	 function manage_content() {
		echo '<div id="manage">';
		$sql = "SELECT * FROM cms_content";
		$res = mysql_query($sql) or die(mysql_error());
		while($row = mysql_fetch_assoc($res)) :
		?>
		
		<div>
			<h2 class="title"><?php echo $row['title'];?></h2>
			<span class="actions"><a href="update_content.php?id=<?php echo $row['id']?>">Edit</a> | <a href="?delete=<?php echo $row['id'];?>">Delete</a></span>
		</div>
		<?php
		endwhile;
		echo '</div>';
		}
		
		function delete_content($id) {
			if(!$id) {
				return false;
				} else {
					$if= mysql_real_escape_string($id);
					$sql="DELETE FROM cms_content WHERE id='$id'";
					$res= mysql_query($sql) or die(mysql_error());
					echo "Content Deleted Successfully!";
			}
			}
			

		
		function update_content($p) {
		
		$title = mysql_real_escape_string($p['title']);
		$body = mysql_real_escape_string($p['body']);
		$id= mysql_real_escape_string($p['id']);

			$sql= "UPDATE cms_content SET title= '$title', body= '$body' WHERE id='$id'";
			$res= mysql_query($sql) or die(mysql_error());
			echo "Update Succesfully!";
        
        }
			

			
			
}//class end he
?>


