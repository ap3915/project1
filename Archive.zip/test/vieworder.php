<?php

session_start();
include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';

$page_title="View Order";
include 'layout_head_admin.php';
    
    $id = $_GET['id'];

    $id = mysql_real_escape_string($id);
			$sql= "SELECT o.order_id, m.name, c.username FROM order_table o 
                        INNER JOIN makanan m ON o.food_id = m.food_id
                        INNER JOIN customer c ON o.user_id = c.user_id";
			$res= mysql_query($sql) or die(mysql_error());
			
    
    //start table
    echo "<table class = 'table table-hover table-responsive table-bordered'>";
    
    //table heading
    echo "<tr>";
    echo "<th>Order ID</th>";
    echo "<th>Name</th>";
    echo "<th>Menu</th>";
    echo "</tr>";
   
    //creating new table row per record
    while ($row = mysql_fetch_array($res, MYSQL_ASSOC)){
    extract ($row);
    
    echo "<tr>";
    echo "<td>{$order_id}</td>";
    echo "<td>{$username}</td>";
    echo "<td>{$name}</td>";
    
    }
        
    echo "</table>";    
include 'layout_foot.php';

    
?>