<?php
session_start();
include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';

$page_title="Order";
include 'layout_head.php';
echo "<form action=\"confirmorder.php\" method=\"post\">"; 
echo "Name : &nbsp <input type=\"text\" name=\"name\">";
echo "<br><br>";
echo "Matric No. : &nbsp <input type=\"text\" name=\"matric\">";
echo "<br><br>";


if(count($_SESSION['cart_items'])>0){
    //get the menu ids
    $ids = "";
    foreach($_SESSION['cart_items'] as $food_id=>$value){
        $ids = $ids . $food_id . ",";
    }
    
    echo $ids = $ids . "0";
    
    //start table
    echo "<table class='table table-hover table-responsive table-bordered'>";
    //table heading
    echo "<tr>";
    echo "<th class='textAlignLeft'>Menu</th>";
    echo "<th>Price (RM)</th>";
    echo "</tr>";
    
    
    $query = "SELECT * FROM makanan WHERE food_id IN ({$ids}) ORDER BY name";
    $res = mysql_query($query) or die(mysql_error());
    

    $total_price=0;
    while($row = mysql_fetch_assoc($res)){
        extract($row);
        
        echo "<tr>";
        echo "<td>{$name}</td>";
        echo "<td>{$price}</td>";
        echo "</tr>";
        
        $total_price+=$price;
    }
    echo "<tr>";
    echo "<td><b>Total</b></td>";
    echo "<td>RM{$total_price}</td>";
    echo "<td>";
    $uname = $_SESSION['customer'];
    echo "<input type=\"submit\" name=\"confirm_submit\" id=\"confirm-submit\" tabindex=\"4\" class=\"form-control btn btn-success\" value=\"Confirm\">";
    echo "</td>";
    echo "</tr>";
    echo "</table>";
   

/*else{
    echo "<div class='alert alert-danger'>";
    echo "<strong>No menus found</strong> in your order ! ";
    echo "</div>";
} */

  
}
    include 'layout_foot.php';
    echo "</form>";  
?>
 