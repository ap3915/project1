<?php

session_start();
$page_title="Add Menu";
include_once 'layout_head_admin.php';



 echo "<table class = 'table table-hover table-responsive table-bordered'>";

	echo"<form method=\"post\" action=\"db_process.php\">";
	echo"<input type=\"hidden\" name=\"update\" value=\"true\" />";
    echo"<input type=\"hidden\" name=\"id\" value=\"#\"/>";
	   echo"<div>";
			echo"<label for=\"title\">Name </label>";
            echo "&nbsp";
			echo"<input type=\"text\" name=\"name\" id=\"title\" value=\"\"/>";
		echo"</div>";
		echo "&nbsp";
		echo"<div>";
			echo"<label for=\"body\">Price (RM)</label>";
            echo "&nbsp";
			echo"<input type=\"text\" name=\"price\" id=\"title\" value=\"\"/>";
    echo"</div>";
    echo "<br><br>";
    echo"<input type=\"submit\" name=\"submit\" value=\"Update Menu\"/>";
	echo"</form>";

include_once 'layout_foot.php';
    
?>