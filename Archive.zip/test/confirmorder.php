<?php

session_start();
$user =  $_SESSION['customer'];
include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';

$page_title="Receipt";
include 'layout_head.php';

    
if(isset($_POST['confirm_submit']))
{
    $nama = $_POST['name'];
    $matrik = $_POST['matric'];
    
}

echo "<table class='table table-hover table-responsive table-bordered'>";
    //table heading
    echo "<tr>";
    echo "<th>Name : $nama<br>";
    echo "Matric No : $matrik<br>";
    echo "</th>";
    echo "</tr>";
     
if(count($_SESSION['cart_items'])>0){
    //get the menu ids
    $ids = "";
    foreach($_SESSION['cart_items'] as $food_id=>$value){
        $submit = "INSERT INTO order_table (user_id, food_id, total_price) VALUES ('$user','$food_id','$total_price')";
        mysql_query($submit) or die(mysql_error());

        $ids = $ids . $food_id . ",";
    }
    
    echo $ids = $ids . "0";
    
    //start table
    echo "<table class='table table-hover table-responsive table-bordered'>";
    //table heading
    echo "<tr>";
    echo "<th class='textAlignLeft'>Menu</th>";
    echo "<th>Price (RM)</th>";
    echo "</tr>";
    
    
    $query = "SELECT * FROM makanan WHERE food_id IN ({$ids}) ORDER BY name";
    $res = mysql_query($query) or die (mysql_error());

    $total_price=0;
    while($row = mysql_fetch_assoc($res)){
        extract($row);
        
        echo "<tr>";
        echo "<td>{$name}</td>";
        echo "<td>{$price}</td>";
        echo "</tr>";
        
        $total_price+=$price;
        
    }
    echo "<tr>";
    echo "<td><b>Total</b></td>";
    echo "<td>RM{$total_price}</td>";

    echo "</table>";
}
else{
    echo "<div class='alert alert-danger'>";
    echo "<strong>No menus found</strong> in your order ! ";
    echo "</div>";
}



unset($_SESSION['cart_items']);
include 'layout_foot.php';
echo "</form>";
?>
