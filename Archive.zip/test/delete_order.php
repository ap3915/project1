<?php

session_start();

include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';
$page_title="Delete Order";
include_once 'layout_head_admin.php';

?>
