<?php

session_start();

include '../web2/db_class/db_class.php';
include '../web2/db_connection/db_connection.php';
include_once 'layout_head_admin.php';

if (isset($_POST['name']) && isset($_POST['price'])){
    $obj->add_content($_POST);
    header("Location: admin.php");
}
include_once 'layout_foot.php';
    
?>

