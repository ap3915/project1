<?php



session_start();
session_destroy();
header("Location: index.html");

if(!isset($_SESSION['admin']))
{
 header("Location: ../web2/index.html");
}
else if(isset($_SESSION['admin'])!="")
{
 header("Location: ../web2/index.html");
}

if(isset($_GET['logout']))
{
 session_destroy();
 unset($_SESSION['admin']);
 header("Location: ../web2/index.html");
}


?>