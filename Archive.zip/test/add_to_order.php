<?php
session_start();

//get the product id
$food_id = isset($_GET['id']) ? $_GET['id'] : "";
$name = isset($_GET['name']) ? $_GET['name'] : "";
$quantity = isset($_GET['quantity']) ? $_GET['quantity'] : "";

/*check if the 'order' session array was created
 *if it is NOT, create the 'order' session array
*/
if(!isset($_SESSION['cart_items'])){
    $_SESSION['cart_items'] = array();
}

// check if the item is in the array, if it is, do not add
if (array_key_exists($food_id, $_SESSION['cart_items'])){
    //redirect to product list and tell the user it was added to cart
    header('Location: menus.php?action=exists&id=' . $food_id . '&name=' . $name);
}

else{
    $_SESSION['cart_items'][$food_id]=$name;
    //redirect to menu list and tell the user it was added to cart
    header('Location: menus.php?action=added&id=' . $food_id . '&name=' . $name);
}
?>