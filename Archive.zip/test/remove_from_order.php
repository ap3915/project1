<?php
session_start();

//get the menu id
$food_id = isset($_GET['food_id']) ? $_GET['food_id'] : "";
$name = isset($_GET['name']) ? $_GET['name'] : "";
//remove the item from the array
unset($_SESSION['cart_items'][$food_id]);
// redirect to product list and tell the user it was added to cart

header('Location: orders.php?action=removed&id=' . $food_id . '&name=' . $name);
?>