<?php
session_start();
include_once 'db_connect.php' ;

$page_title="Order";
include 'layout_head.php';

$action = isset($_GET['action']) ? $_GET['action'] : "";
$name = isset($_GET['name']) ? $_GET['name'] : "";

if($action=='removed'){
    echo "<div class='alert alert-info'>";
    echo "<strong>{$name}</strong> was removed from your order !";
    echo "</div>";
}
else if($action=='quantity_updated'){
    echo "<div class='alert alert-info'>";
    echo "<strong>{$name}</strong> quantity was updated !";
    echo "</div>";
}
if(count($_SESSION['cart_items'])>0){
    //get the menu ids
    $ids = "";
    foreach($_SESSION['cart_items'] as $food_id=>$value){
        $ids = $ids . $food_id . ",";
    }
    
    echo $ids = $ids . "0";
    
    //start table
    echo "<table class='table table-hover table-responsive table-bordered'>";
    //table heading
    echo "<tr>";
    echo "<th class='textAlignLeft'>Menu</th>";
    echo "<th>Price (RM)</th>";
    echo "<th>Action</th>";
    echo "</tr>";
    
    $query = "SELECT * FROM makanan WHERE food_id IN ({$ids}) ORDER BY name";
    
    $stmt = $con->prepare($query);
    $stmt->execute();
    
    $total_price=0;
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        
        echo "<tr>";
        echo "<td>{$name}</td>";
        echo "<td>{$price}</td>";
        echo "<td>";
        echo "<a href='remove_from_order.php?food_id={$food_id}&name={$name}' class='btn btn-danger'>";
        echo "<span class='glyphicon glyphicon-remove'></span> Remove from order";
        echo "</a>";
        echo "</td>";
        echo "</tr>";
        
        $total_price+=$price;
    }
    echo "<tr>";
    echo "<td><b>Total</b></td>";
    echo "<td>RM{$total_price}</td>";
    echo "<td>";
    echo "<a href='submitorder.php' class='btn btn-success'>";
    echo "<span class='glyphicon glyphicon cutlery'></span> Checkout";
    echo "</a>";
    echo "</td>";
    echo "</tr>";
    echo "</table>";
}
else{
    echo "<div class='alert alert-danger'>";
    echo "<strong>No menus found</strong> in your order ! ";
    echo "</div>";
}
include 'layout_foot.php';

?>