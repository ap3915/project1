<?php
session_start();

$page_title="Menu";

include 'layout_head.php';

//to prevent undefined index notice
$action = isset($_GET['action']) ? $_GET['action'] : "";
$food_id = isset($_GET['food_id']) ? $_GET['food_id'] : "1";
$name = isset($_GET['name']) ? $_GET['name'] : "";

if($action=='added'){
    echo "<div class = 'alert alert-info'>";
    echo "<strong>{$name}</strong> was added to your order !";
    echo "</div>";
}

if($action=='exists'){
    echo "<div class = 'alert alert-info'>";
    echo "<strong>{$name}</strong> already exists in your order !";
    echo "</div>";
}

$query = "SELECT * FROM makanan ORDER BY name";
$stmt = $con->prepare($query);
$stmt->execute();

$num = $stmt->rowCount();

if($num>0){
    //start table
    echo "<table class = 'table table-hover table-responsive table-bordered'>";
    
    //our table heading
    echo "<tr>";
    echo "<th class = 'textAlignLeft'>Menu</th>";
    echo "<th>Price (RM)</th>";
    echo "<th>Action</th>";
    echo "</tr>";
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract ($row);
        
        //creating new table row per record
        echo "<tr>";
        echo "<td>";
        echo "<div class='food_id' style='display:none;'>{$food_id}</div>";
        echo "<div class='menu'>{$name}</div>";
        echo "</td>";
        echo "<td>{$price}</td>";
        echo "<td>";
        echo "<a href = 'add_to_order.php?id={$food_id}&name={$name}' class='btn btn-primary'>";
        echo "<span class='glyphicon glyphicon-cutlery'></span> Add to order";
        echo "</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

else{
    echo "No foods found.";
}

include 'layout_foot.php';
?>